/*
 * PacMan is the user and starts at the bottom center of the screen.
 * PacMan is equal distance away from two power pellets but always 
 * starts out facing the left side of the screen and starts to move 
 * in that direction unless the user changes the direction.
 * 
 * He starts out with three lives but loses a life everytime a ghost
 * is touched.  Lives can be gained with each 10,000 points.
 * 
 * Title: PacMan Class version 1.0
 * Date: February 15, 2009
 * Author: Nicole Waldrum
 */
public class PacMan extends Character {

}
