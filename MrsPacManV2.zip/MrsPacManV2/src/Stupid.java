/*
 * This Stupid class is the orange ghost, whose behaviour is pokey.
 * This ghost is released from the ghost prison last.
 * Stupid has random movements hence the characters name.
 * The repsective corner is the bottom left of the screen.
 * 
 * Title: Stupid Class version 1.0
 * Date: February 15, 2009
 * Author: Nicole Waldrum
 */
public class Stupid extends Character {

}
