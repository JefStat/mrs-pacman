/*
 * This class controls the size of the map and also feed into coordinate to 
 * know what is occurring in the map at any given time.
 * 
 * Title: Map Class version 1.0
 * Date: February 15, 2009
 * Author: Nicole Waldrum
 */
public class Map extends PacManGame {

}
