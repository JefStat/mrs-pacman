/*
 * This Fickle class is the blue ghost, whose behaviour is bashful.
 * Released third out of the ghost pen after Chaser and Ambusher are off.
 * Fickle will move about the board randomly but may follow if close to PacMan.
 * The repsective corner is the bottom right of the screen.
 * 
 * Title: Fickle Class version 1.0
 * Date: February 15, 2009
 * Author: Nicole Waldrum
 */
public class Fickle extends Character {

}
